#' Pool individual genotypes into allele arrays
#'
#' This function converts individual genotypes offspring into an array of allele present at each locus, in each brood.
#' @param x object of class data.frame. See output of read.gdata(), $g.types, or sim.brood(), $F1
#' 
#' @details Output of pool.it is a list which includes the following:
#'  
#' $alleles: Data frame of alleles present at each locus for each brood.
#' 
#' $loci: The names of microsatellite loci present in dataset.
#' 
#' $n.brood: Number of broods in dataset.
#' 
#' $na.brood: Data frame of the number of alleles for each locus, for each brood.
#' @keywords populations, number of alleles per locus, NA
#' @author Tyler Jackson
#' @export
#' @examples
#' pool.it(tmp)

pool.it <- function(x){
  
  A <- num.alleles(x, seppop=T)
  if(exists("A")==F){stop("Invalid input data.frame. See tutorial.")}
  max.na <- NULL
  for(i in 1:(ncol(A)-1)){
    max.na[i] <- max(A[,i+1])
  }
  
  B <- sep.pop(x)
  
  Q <- lapply(B, FUN=function(k){
    afrq <- allele.freq(k)
    a <- sapply(afrq, FUN=function(x){x <- x[,1]})
    names(a) <- gsub("\\.", "|", names(a))
    for(i in 1:length(a)){
      a[[i]] <- c(a[[i]], rep(NA, max.na[i]-length(a[[i]])))
      a[[i]] <- rbind(as.character(paste0(names(a[i]),"_",1:max.na[i])), as.numeric(a[[i]]))
      a[[i]] <- as.data.frame(a[[i]])
      names(a[[i]]) <- paste0(1:max.na[i])
      a[[i]] <- a[[i]][-1,]
    }
    do.call("cbind", a)
  })
  for(i in 1:length(Q)){
    x <- data.frame("brood"=names(Q[i]))
    Q[[i]] <- cbind(x,Q[[i]])
  }
  Z <- do.call("rbind", Q)  
  row.names(Z) <- NULL
  names(Z) <- gsub("\\.","_",names(Z))
  names(Z) <- sub("|",".",names(Z), fixed=T)
  
  names(A) <- c("brood", names(A)[-1])
  
  list(alleles=Z,
       loci=names(A)[-1],
       n.brood=length(B),
       na.brood=A)
}
