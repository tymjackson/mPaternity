#' Calculate the number of allele per locus
#'
#' This function calculates the number of alleles per locus, either for each population or the entire dataset
#' @param x object of class data.frame. See output of read.gdata(), $g.types
#' 
#' @param seppop logical operater to determine if data is to be divided by population, default = TRUE
#' 
#' @details If seppop=TRUE the output consists of a data frame with rows representing the number of alleles at each locus, in each population.
#' @keywords populations, number of alleles per locus, NA
#' @author Tyler Jackson
#' @export
#' @examples
#' num.alleles(tmp1, seppop=T)


num.alleles <- function(x, seppop=T){
  if(seppop==T){
  a <- allele.freq(x, seppop=T, missingdata=F)
  Q <- data.frame(Site=names(a))
  for(i in 1:length(a)){
    for(j in 1:length(a[[i]])){
      b <- lapply(a[[i]], FUN=nrow)
      Q[i, j+1] <- unlist(b)[j]
    }
  }
  names(Q) <- c("Site", names(a[[1]]))
  Q
  }
  else if(seppop==F){
    a <- allele.freq(x, seppop=F, missingdata=F)
    b <- lapply(a, FUN=nrow)
    unlist(b)
  }
  else{stop("seppop argument not recognized. TRUE or FALSE")}
}

