#' Calculate allele frequencies
#'
#' This function calculates allele frequencies at each locus for the enitre dataset or each population separately, with and without including missing data. 
#' @param x object of class data.frame. See output of read.gdata(), $g.types
#' 
#' @param seppop logical operater to determine if data is to be divided by population, default = FALSE
#' 
#' @param missingdata logical operater to determine if allele frequencies should include NA's, default = FALSE
#' @details Allele frequencies for each locus in a data.frame of genotype data (see read.gdata) are calculated. If seppop=FALSE, output is a 
#' list containing a data frame of allele frequencies for each locus. If seppop=FALSE, output is a nested
#' list containing a list for each site, with data frames of allele frequencies for each locus.
#' @keywords populations, allele frequncey
#' @author Tyler Jackson
#' @export
#' @examples
#' allele.freq(tmp1, seppop=F, missingdata=T)




allele.freq <- function(x, seppop=FALSE, missingdata=FALSE){
  if(class(x)=="data.frame"){
  if(seppop==F && missingdata==F){
  loc <- names(x)
  loc <- loc[grepl("_1", loc)]
  loc <- gsub("_1","",loc) #locus names
  output <- list(NULL)
  d <- NULL
  for(i in 1:length(loc)){
    d <- x[,grep(pattern=loc[i],x=names(x))] 
    h <- c(d[,1],d[,2])
    length(h)
    k <- unique(h); k <- k[!is.na(k)];k <- sort(k)
    l <-NULL
  for(j in 1:length(k)){
    l[j] <- sum(h[!is.na(h)]==k[j])/length(h[!is.na(h)])
    }
    output[[i]] <- if(is.na(k[1])){data.frame(Allele=NA, Frequency=NA)}else{data.frame(Allele=k, Frequency=l)}
  }
  names(output) <- loc
  output
  }

else if(seppop==T && missingdata==F){
    q <- sep.pop(x)
    lapply(q, FUN=function(z){
    loc <- names(z)
    loc <- loc[grepl("_1", loc)]
    loc <- gsub("_1","",loc) #locus names
    output <- list(NULL)
    d <- NULL
    for(i in 1:length(loc)){
      d <- z[,grep(pattern=loc[i],x=names(z))]
      h <- c(d[,1],d[,2])
      length(h)
      k <- unique(h, na.rm=T); k <- k[!is.na(k)];k <- sort(k)
      l <-NULL
      for(j in 1:length(k)){
        l[j] <- sum(h[!is.na(h)]==k[j])/length(h[!is.na(h)])
      }
      output[[i]] <- if(is.na(k[1])){data.frame(Allele=NA, Frequency=NA)}else{data.frame(Allele=k, Frequency=l)}
    }
    names(output) <- loc
    output
  })
}
else if(seppop==F && missingdata==T){
  loc <- names(x)
  loc <- loc[grepl("_1", loc)]
  loc <- gsub("_1","",loc) #locus names
  output <- list(NULL)
  d <- NULL
  for(i in 1:length(loc)){
    d <- x[,grep(pattern=loc[i],x=names(x))] 
    h <- c(d[,1],d[,2])
    h[is.na(h)] <- 0
    length(h)
    k <- unique(h); k <- sort(k)
    l <-NULL
    for(j in 1:length(k)){
      l[j] <- sum(h==k[j])/length(h)
    }
    k[k==0] <- NA
    output[[i]] <- if(is.na(k[1])){data.frame(Allele=NA, Frequency=NA)}else{data.frame(Allele=k, Frequency=l)}
  }
  names(output) <- loc
  output
}
else if(seppop==T && missingdata==T){
  q <- sep.pop(x)
  lapply(q, FUN=function(z){
    loc <- names(z)
    loc <- loc[grepl("_1", loc)]
    loc <- gsub("_1","",loc) #locus names
    output <- list(NULL)
    d <- NULL
    for(i in 1:length(loc)){
      d <- z[,grep(pattern=loc[i],x=names(z))]
      h <- c(d[,1],d[,2])
      h[is.na(h)] <- 0
      length(h)
      k <- unique(h); k <- sort(k)
      l <-NULL
      for(j in 1:length(k)){
        l[j] <- sum(h==k[j])/length(h)
      }
      k[k==0] <- NA
      output[[i]] <- if(is.na(k[1])){data.frame(Allele=NA, Frequency=NA)}else{data.frame(Allele=k, Frequency=l)}
    }
    names(output) <- loc
    output
  })
}
}
else{stop("Invalid argument. x must be object of class data.frame in correct format. See function read.gdata")}

}
