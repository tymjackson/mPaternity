#' Estimate the minimum number of sires in pooled brood
#'
#' This function uses an array of alleles present in a pooled offspring sample (i.e., a brood) and the known parent's (most likely mother's) genotype across all loci to 
#' estimate the minimum number of sires respresented in each brood.
#' @param broods array of alleles present at each locus in each brood. See output of read.brood(),$alleles
#' 
#' @param moms object of class data.frame respresnting multilocus genotypes of known parents. See output of read.gdata(), $g.types
#' 
#' @details The minimum number of sires represented in each brood is estimated based on an array of alleles present at each locus in each brood
#' and the multilocus genotype of the known parent. The output is an object of class data.frame with a column 'brood' representing the identifier 
#' for each brood, and a second column 'minSire' indicating the minimum number of sires corresponding to each brood. Note that 
#' 'minSire' represents the MINIMUM number of sires, not the ACTUAL.
#' @keywords multiple paternity, minimum number of sires, brood
#' @author Tyler Jackson
#' @export
#' @examples
#' min.sires(broods=pooledoffspring, moms=momgtypes)

minimum.sires <- function(broods, moms){
  if(missing(broods)){stop("Must provide array of alleles present at each locus in broods.")}
  if(missing(moms)){
    moms <- data.frame(Pop=1,
                             Ind=broods$brood)
    moms <- cbind(moms,broods[,grep("_1|_2", names(broods))])
    moms <- as.matrix(moms)
    moms[,c(3:ncol(moms))] <- 9999
    moms <- as.data.frame(moms)
  }
    
  loc <- names(moms)
  loc <- loc[grepl("_1", loc)]
  loc <- gsub("_1","",loc) #locus names

  minsires <- data.frame(brood=broods[,1])
  for(j in broods$brood){
  Q <- list()
  for(i in 1:length(loc)){
  a <- as.numeric(moms[moms[,2]==j, grepl(paste0(loc[i],"_"), names(moms))]) #isolate alleles for mom at a single locus
  b <- as.numeric(as.matrix(broods[broods$brood==j, grepl(paste0(loc[i],"_"), names(broods))])) #isolate alleles for a brood at a single locus
  Q[[i]] <- b[!b%in%a] #remove alleles matching the mother at that locus
  }
  Q <- lapply(Q, function(x){x <- x[!is.na(x)]})
  names(Q) <- loc
  Z <- data.frame()
  for(i in 1:length(loc)){
  Z[1,i] <- length(Q[[i]])
  }
  Z
  Z <- cbind(broods$brood[j], Z)
  names(Z) <- c("brood", loc) #number of non maternal alleles at each locus

  min <- ceiling(max(Z[,-1])/2)#minimum number of sires for that brood
  minsires$minSire[minsires$brood==j] <- min
  }
  minsires
}
