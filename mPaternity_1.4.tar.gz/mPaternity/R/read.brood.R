#' Import Genetic Data of Pooled Offspring
#'
#' This function imports allele arrays of offspring (i.e., each brood) to be used in mutiple paternity analysis. 
#' @param x File name with extension, in quotations. 
#' @details See mPaternity tutorial for instructions on creating a pooled offspring input file. Output of read.brood is a list which
#' includes the following:
#'  
#' $alleles: Data frame of alleles present at each locus for each brood.
#' 
#' $loci: The names of microsatellite loci present in dataset.
#' 
#' $n.brood: Number of broods in dataset.
#' 
#' $na.brood: Data frame of the number of alleles for each locus, for each brood.
#' 
#' @keywords genotypes, allele arrays
#' @author Tyler Jackson
#' @export
#' @examples
#' read.offspring("awesomeoffspring.txt", pooled=T)


read.brood <- function(x){
    in.file <-read.table(x, sep="\t", na.s=c("0","00","000000","NA"), header = T, colClasses = "character")
    a <- grep("\\.", names(in.file), value=T)
    loci <- grep("\\.", names(in.file), value=T, invert=T)
    loci <- loci[-1] #loci names
    n.loci <- length(unique(loci)) #number of loci
    n.brood <- length(unique(in.file$brood)) #number of broods
    c <- data.frame(brood=in.file$brood)
    for(i in 1:nrow(c)){
    for(j in 1:n.loci){
    b <- cbind(in.file[i,1], in.file[i,grepl(loci[j], names(in.file))])
    c[i,j+1] <- ncol(b)-1-sum(is.na(b[1,]))
    }}
    names(c) <- c("brood", loci)
    na.brood <- c #number of alleles per for each brood per loci
    
    list(alleles=in.file,
         loci=loci,
         n.brood=n.brood,
         na.brood=c)
}