README for mPaternity

Download most recent .tar.gz file. mPaternity1.0.tar.gz is decrepit.

To install library in R from a local directory, using the following command:

> install.packages("path_to_tar.gz_file", repos=NULL, type="source")

Tutorial under construction

For questions email Tyler Jackson, tyler.jackson@alaska.gov