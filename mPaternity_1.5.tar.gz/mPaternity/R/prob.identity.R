#' Calculate probability of identity (PI)
#'
#' This function calculates the probability of identity (PI). 
#' @param x object of class data.frame. See output of read.gdata, $g.types. This function will not subset populations automatically (see sep.pop).
#' 
#' @param all.loci logical operater to determine if PI is to be calculate across all loci, default = TRUE.
#' 
#' @param locus numerical string indicating which loci to include in calculation of PI. Loci are numbered in the order they are listed in x, from left to right.
#' @details Probability of identity (PI) (i.e., the probability of two unrelated individuals having identical genotypes) is calculated and returned using the specified parameters.
#' @keywords probability of identity, genotypes
#' @author Tyler Jackson
#' @export
#' @examples
#' prob.identity(tmp1, all.loci=F, locus=c(1,3,7))



prob.identity <- function(x, all.loci=TRUE, locus){

if(all.loci==F&&missing(locus)){stop("Must specific which locus(i)")}

af <- allele.freq(x) #get allele frequencies
if(all.loci==F){af <- af[c(locus)]} #subset data if instructed to

P <- NULL #get the probability of having the same genotype at each locus
for(i in 1:length(af)){
   z <- as.data.frame(af[i])
z[,3] <- z[,2]^2
z[,4] <- z[,2]^4
P[i] <- 2*(sum(z[,3]))^2-sum(z[,4])
  }
prod(P) #combine probabilities across several loci
}

