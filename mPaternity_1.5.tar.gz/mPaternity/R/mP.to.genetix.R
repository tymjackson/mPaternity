#' Change Genetic Data Format from mPaternity to Genetix
#'
#' This function converts multilocus genotypes of individuals used in mPaternity to being formatted as an input file for the software program GENETIX (Belkhir et al. 2004)
#' @param x object of class data.frame. See output of read.gdata(), $g.types
#' @param file character string indicating the desired name of the file. "_genetix.txt" will automatically be added on.
#' @param export logical operater to determine if data should be stored in the environment as an object of class data.frame (FALSE) or exported as a text file (TRUE).
#' @details A text file in the GENETIX input file format will be saved in the working directory.
#' @keywords genotypes, GENETIX
#' @author Tyler Jackson
#' @references Belkhir K., Borsa P, Chikhi L, Raufaste N, Bonhomme F (2004) GENETIX 4.05: logiciel
#' sous WindowsTM pour la génétique des populations. Laboratoire Génome,
#' populations, interactions, CNRS UMR 5171, Université de Montpellier II,
#' Montpellier, France.
#' @export
#' @examples
#' mP.to.genetix(mydata$g.types, file="mydata")

mP.to.genetix <- function(x, export=T, file){
  loci <- names(allele.freq(x))
  y <- data.frame(Pop=x[,2], Ind=x[,1])
  for(i in 1:length(loci)){
    y[,(2+i)] <- paste0(x[,(2+(2*i-1))], x[,(2+(2*i))])
  }
  names(y) <- c(loci, "", "")
  if(export==F){y} else{
  write.table(y, paste0(file,"_genetix.txt"), row.names=F,sep="\t", quote = FALSE)
  }
}
