#' Normalize a vector to sum to 1
#'
#' This function scales numerical vectors to sum to 1
#' @param x numerical vector
#' @details writes numerical vector so that the sum of all elements equals 1
#' @keywords 
#' @author Tyler Jackson
#' @export
#' @examples
#' norm(df[,c(1:30)])

norm <- function(x){if(sum(x, na.rm=T)==0){0} else{x/sum(x, na.rm=T)}}

