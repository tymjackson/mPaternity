#' Import Multilocus Genetic Data
#'
#' This function imports multilocus genotypes of individuals formatted as an input file for the software program GENETIX (Belkhir et al. 2004)
#' or Genepop (Raymond and Rousset 1995; Rousset 2008)
#' @param x File name with extension, in quotations
#' @param format Input format of x. Either "genetix" or "genepop"
#' @details GENETIX file must be formatted as 4 or 6 digits, missing data denoted as 0. Output consists of a list containing:
#'  
#' $gtypes: Data frame of multilocus genotypes for each individual.
#' 
#' $n.loci: The number of microsatellite loci present in dataset.
#' 
#' $n.Pop: Number of populations or sampling sites.
#' 
#' $missing.data: Data frame of individuals missing data at one or more loci.
#' @keywords genotypes
#' @author Tyler Jackson
#' @references Belkhir K., Borsa P, Chikhi L, Raufaste N, Bonhomme F (2004) GENETIX 4.05: logiciel
#' sous WindowsTM pour la génétique des populations. Laboratoire Génome,
#' populations, interactions, CNRS UMR 5171, Université de Montpellier II,
#' Montpellier, France.
#' @references Raymond M. & Rousset F, 1995. GENEPOP (version 1.2): population genetics software for exact tests and ecumenicism. J. Heredity, 86:248-249
#' @references Rousset, F., 2008. Genepop'007: a complete reimplementation of the Genepop software for Windows and Linux. Mol. Ecol. Resources 8: 103-106.
#' @export
#' @examples
#' read.gdata("awesomedata.txt", format="genetix")

read.gdata <- function(x, format){
  
  if(missing(format)){stop("Must provide input file format, no default. genepop or genetix.")}
  else if(format=="genetix"){
  in.file <-read.table(x, sep="\t", na.s=c("0","00","000000","NA"), header = T, colClasses = "character")
  loci<-names(in.file[-c(ncol(in.file), ncol(in.file)-1)])
  names(in.file)<-c("Pop","Ind",loci)
  is.whole <- function(a) { 
    (is.numeric(a) && floor(a)==a) ||
      (is.complex(a) && floor(Re(a)) == Re(a) && floor(Im(a)) == Im(a))
  }
  mat <- matrix(nrow=nrow(in.file), ncol=length(loci)*2)
  for(i in 1:length(loci)){
    loc <- in.file[,i+2]
    form <- max(nchar(loc), na.rm=T)
    mat[,i*2-1] <- as.numeric(substring(loc, c(1), c(form/2)))
    mat[,i*2] <- as.numeric(substring(loc, c(form/2+1), c(form)))
  }
  mat<- as.data.frame(mat)
  nom<-NULL
  for(i in 1:ncol(mat)){
    nom[i] <- paste0(loci[ceiling(i/2)],"_",ifelse(is.whole(i/2)==F,1,2))
  }
  in.file <- cbind(in.file[,c(1,2)],mat)
  names(in.file) <- c("Pop","Ind", nom)
  list(
    g.types = in.file,
    n.loci = length(loci),
    n.ind = nrow(in.file),
    n.Pop = length(unique(in.file$Pop)),
    missing.data = in.file[rowSums(is.na(in.file)) > 0,]
  )
  }
else if(format=="genepop"){
  in.file <-read.table(x, sep="\t", na.s=c("0","00","000","0000","000000","NA"), header = T, colClasses = "character") 
  a <- match("Pop", in.file[,1])
  loci <- as.vector(in.file[c(1:a-1),1])
  in.file <- in.file[-c(1:a-1),1]
  in.file <- in.file[in.file!="Pop"]
  in.file <- read.table(text=in.file, sep=" ", colClasses = "character")
  names(in.file) <- c("Pop", loci)
  in.file$Pop <- gsub(",", "", in.file$Pop)
  b <- data.frame(Pop=in.file$Pop, Ind=c(1:nrow(in.file)))
  mat <- matrix(nrow=nrow(in.file), ncol=length(loci)*2)
  for(i in 1:length(loci)){
    loc <- in.file[,i+1]
    form <- max(nchar(loc),na.rm=T)
    mat[,i*2-1] <- as.numeric(substring(loc, c(1), c(form/2)))
    mat[,i*2] <- as.numeric(substring(loc, c(form/2+1), c(form)))
  }
  in.file <- as.data.frame(cbind(b,mat))
  nom<-NULL
  is.whole <- function(a) { 
    (is.numeric(a) && floor(a)==a) ||
      (is.complex(a) && floor(Re(a)) == Re(a) && floor(Im(a)) == Im(a))
  }
  for(i in 1:ncol(mat)){
    nom[i] <- paste0(loci[ceiling(i/2)],"_",ifelse(is.whole(i/2)==F,1,2))
  }
  names(in.file) <- c("Pop", "Ind", nom)
  in.file[in.file==0] <- NA
  list(
    g.types = in.file,
    n.loci = length(loci),
    n.ind = nrow(in.file),
    n.Pop = length(unique(in.file$Pop)),
    missing.data = in.file[rowSums(is.na(in.file)) > 0,]
  )
}
  else stop("Invalid input format")
}


