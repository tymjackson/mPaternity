#' Separate individuals by population
#'
#' This function divides individuals into spearate datasets according to population. 
#' @param x object of class data.frame. See output of read.gdata, $g.types
#' @details A data.frame of genotype data (see read.gdata) is separated by the column 'Pop' (i.e. population) and returns a 
#' list containing a data.frame corresponding to each population.
#' @keywords populations, sampling site
#' @author Tyler Jackson
#' @export
#' @examples
#' sep.pop(tmp$Pop)



sep.pop <- function(x){
  Q <- list(NULL)
  pop <- unique(x[,1])
  for (i in 1:length(pop)){
    Q[[i]] <- subset(x, x[,1]==pop[i])
    
  }
  names(Q) <- pop
  Q
} 