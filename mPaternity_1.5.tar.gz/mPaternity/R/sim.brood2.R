#' Simulate genotypes of a multiply sired brood, based on an observed sample
#'
#' This function generates simulated microsatellite genotypes of parents and offspring in a single, multiply sired brood.
#' @param x object of class data.frame or list (see pop.samp) that simulated genotypes is based on.
#' 
#' @param pop.samp Logical, TRUE or FALSE. If TRUE, x is an object of class data.frame representing genotypes of individuals. See
#' output of read.gdata(), $g.types. If FALSE, x is a list of alleles present at each locus and their frequencies. See output of allele.freq().
#'     
#' @param n.offspring Number of offspring to be simulated. Default = 1000.
#' 
#' @param n.sires Number of sires contributing to brood.
#' 
#' @param fert.success Object of class vector representing the proportion of the brood sired by each putative sire. Sum must be equal to 1.
#' 
#' @param split Logical, TRUE or FALSE. If TRUE, the output consists of a list containing a separate dataframe for genotypes of parents (P) 
#' and offspring (F1).
#' 
#' @details For each locus in x, sim.brood2 generates genotypes of a single mother and a user defined number of sires (i.e., P) based on observed allele frequencies in the population. sim.brood2 then simulates a brood of a user defined number of offspring, with genotypes generated 
#' from mating between individuals in P. Proption of the brood sired by each putative sire in P is user define (i.e., fert.success). Mating follows Mendelian inheritance.
#' @keywords simulate, genotypes, brood
#' @author Tyler Jackson
#' @export
#' @examples
#' sim.brood2(pop.gtypes, pop.samp=T, n.offspring=1000, n.sires=2, fert.success=c(0.5, 0.5), split=T)


sim.brood2 <- function(x, pop.samp=T, n.offspring=1000, n.sires, fert.success, split=T){
  if(missing(n.sires)){stop("Must provide number of sires")}
  if(missing(fert.success)){stop("Must provide fert.success for each sire")}
  if(sum(fert.success)!=1){stop("Sum of fert.success must be equilivant to 1")}
  if(pop.samp==T){
  A <- allele.freq(x)} else {A <- x}
  
  Q <- data.frame(Brood=rep("Brood_1",n.sires+1),Ind = c("Mom", paste0("Dad_", 1:n.sires)))
  #parents genotypes
  for(i in 1:length(A)){
    allele.uno <- sample(A[[i]][,1], 1+n.sires, prob=A[[i]][,2], replace=T) #draw alleles to be genotypes for the parents
    allele.dos <- sample(A[[i]][,1], 1+n.sires, prob=A[[i]][,2], replace=T)
    gtype <- as.data.frame(cbind(allele.uno,allele.dos))
    names(gtype) <- c(paste0(names(A)[i],"_", 1:2))
    Q <- cbind(Q, gtype)
  }
  #offsprings genotypes
  Y <- list()
  for(i in 1:n.sires){
    a <- Q[1,]
    b <- Q[1+i,]
    fs <- fert.success[i]  
    n.off.sired <- fs*n.offspring
    Y[[i]] <- data.frame(X=1:n.off.sired)
    for(j in 1:length(A)){
      #allele from mom
      m <- as.numeric(a[,c(j*2+1,j*2+2)])
      allele.uno <- sample(m, n.off.sired, replace=T)
      #allele from dad
      d <- as.numeric(b[,c(j*2+1,j*2+2)])
      allele.dos <- sample(d, n.off.sired, replace=T)
      gtype <- as.data.frame(cbind(allele.uno,allele.dos))
      names(gtype) <- c(paste0(names(A)[j],"_", 1:2))
      Y[[i]] <- cbind(Y[[i]], gtype)
    }
  }
  Z <- do.call("rbind", Y) #combine all sires' contributions
  Z <- Z[,-1] #remove X
  W <- data.frame(Brood=rep("Brood_1", n.offspring),Ind=paste0("Offspring_", 1:n.offspring))
  Z <- cbind(W, Z)
  
  if(split==T){
    list(P=Q, F1=Z)
  } else
    if(split==F){
      rbind(Q, Z)} else {stop("Do not recognize argument for 'split'. Must be TRUE or FALSE")}
}