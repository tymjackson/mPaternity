#' Estimate the minimum number of sires in a brood
#'
#' This function uses an genotypes of offspring (i.e., a brood) and the known parent's (most likely mother's) genotype across all loci to 
#' estimate the minimum number of sires respresented in each brood.
#' @param broods object of class data.frame respresenting multilocus genotypes of offspring. See output of read.gdata(), $g.types
#' 
#' @param moms object of class data.frame respresenting multilocus genotypes of known parents. See output of read.gdata(), $g.types
#' 
#' @details The minimum number of sires represented in each brood is estimated based on an array of alleles present at each locus in each brood
#' and the multilocus genotype of the known parent. The output is an object of class data.frame with a column 'brood' representing the identifier 
#' for each brood, a column representing the number of unique alleles per locus found within the brood, and a last column 'min.sire' indicating the minimum number of sires corresponding to each brood. Note that 
#' 'min.sire' represents the MINIMUM number of sires, not the ACTUAL.
#' @keywords multiple paternity, minimum number of sires, brood
#' @author Tyler Jackson
#' @export
#' @examples
#' min.sires(broods=offspringgtypes, moms=momgtypes)

minimum.sires <- function(broods, moms){
  if(missing(broods)){stop("Must provide array of alleles present at each locus in broods.")}
  if(missing(moms)){
    moms <- data.frame(Pop=1,
                             Ind=broods$brood)
    moms <- cbind(moms,broods[,grep("_1|_2", names(broods))])
    moms <- as.matrix(moms)
    moms[,c(3:ncol(moms))] <- 9999
    moms <- as.data.frame(moms)
  }
    
  loc <- names(moms)
  loc <- loc[grepl("_1", loc)]
  loc <- gsub("_1","",loc) #locus names

  e.list <- list()
  for(i in loc){
    e.list[[i]] <- broods[,c(1,grep(i,names(broods)))]
  }
  e.list <- lapply(e.list, function(x){
    #remove mom contributed allele, leave sire contributed allele
    for(i in unique(x$Pop)){
      mom <- as.numeric(moms[moms$Ind==i, grep(gsub("_1", "", names(x)[2]), names(moms))])
      a <- paste0(x[x$Pop==i,2], x[x$Pop==i,3])
      m <- paste0(mom[1], mom[2])
      h1 <- paste0(substring(m, 1,3),substring(m, 1,3))
      h2 <- paste0(substring(m, 4,6),substring(m, 4,6))
      for(j in 1:length(a)){
        if(m==paste0(x[x$Pop==i,2][j],x[x$Pop==i,3][j]) & h1%in%a){
          x[x$Pop==i,2][j] <- ifelse(x[x$Pop==i,2][j]==as.numeric(substring(h2,1,3)), NA,x[x$Pop==i,2][j])
          x[x$Pop==i,3][j] <- ifelse(x[x$Pop==i,3][j]==as.numeric(substring(h2,1,3)) & !is.na(x[x$Pop==i,2][j]), NA,x[x$Pop==i,3][j])
        }else{
          if(m==paste0(x[x$Pop==i,2][j],x[x$Pop==i,3][j]) & h2%in%a){
            x[x$Pop==i,2][j] <- ifelse(x[x$Pop==i,2][j]==as.numeric(substring(h1,1,3)), NA,x[x$Pop==i,2][j])
            x[x$Pop==i,3][j] <- ifelse(x[x$Pop==i,3][j]==as.numeric(substring(h1,1,3)) & !is.na(x[x$Pop==i,2][j]), NA,x[x$Pop==i,3][j])
          }else{
            x[x$Pop==i,2][j] <- ifelse(x[x$Pop==i,2][j]%in%mom, NA,x[x$Pop==i,2][j])
            x[x$Pop==i,3][j] <- ifelse(x[x$Pop==i,3][j]%in%mom & !is.na(x[x$Pop==i,2][j]), NA,x[x$Pop==i,3][j])
          }
        }
      }
    }
    x
  })
  
  #remove first column
  e.list[2:length(e.list)] <- lapply(e.list[2:length(e.list)], function(x){
    x <- x[,c(2:ncol(x))]
    x
  })
  es <- do.call("cbind", e.list)
  names(es)[1] <- "brood"
  
  e.list <- split(es, factor(es$brood))
  
  e.list <- lapply(e.list, function(x){
    Q <- list()
    for(i in loc){
      alleles <- unique(na.omit(as.numeric(as.matrix(x[, grep(i,names(x))]))))
      Q[[i]] <- length(alleles)
    }
    W <- as.data.frame(do.call(cbind, Q))
    W$min.sire <- ceiling(max(W[,-1])/2)
    W
  })
  
  A <- cbind(names(e.list),do.call(rbind, e.list))
  names(A)[1] <- "brood"
  row.names(A) <- c(1:nrow(A))
  A
}