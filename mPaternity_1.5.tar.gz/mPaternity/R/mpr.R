#' Calculate Match Probability Ratio (MPR)
#'
#' This function calculates the Match Probability Ratio (MPR) between individual genotypes. 
#' @param x object of class data.frame. See output of read.gdata, $g.types. This function will not subset populations automatically (see sep.pop).
#' 
#' @param all.loci logical operater to determine if MPR is to be calculate across all loci, default = TRUE.
#' 
#' @param locus numerical string indicating which loci to include in calculation of PI. Loci are numbered in the order they are listed in x, from left to right.
#' @details Match Probability Ratio (MPR) (i.e., the probability of two unrelated individuals having identical genotypes) is calculated conservatively the frequency of the most common allele at a specific locus squared. MPR of multiple loci is the product of MPR estimates at each locus.
#' @keywords Match Probability Ratio, genotypes
#' @author Tyler Jackson
#' @export
#' @examples
#' mpr(tmp1, all.loci=F, locus=c(1,3,7))



mpr <- function(x, all.loci=TRUE, locus){
  
  if(all.loci==F&&missing(locus)){stop("Must specific which locus(i)")}
  
  af <- allele.freq(x) #get allele frequencies
  if(all.loci==F){af <- af[c(locus)]} #subset data if instructed to
  
  P <- NULL #max frequency at each locus squared
  for(i in 1:length(af)){
    z <- as.data.frame(af[i])
    P[i] <- max(z[,2])^2
  }
  prod(P) #combine probabilities across several loci
}

