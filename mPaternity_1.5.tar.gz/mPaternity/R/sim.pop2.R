#' Simulate genotypes of a sample population based on known population allele frequencies.
#'
#' This function generates simulated microsatellite genotypes of parents and offspring in a single, multiply sired brood.
#' @param x object of class list containing a data frame for each locus, with allele names in the first column and allele frequencies in the second column. See output of allele.freq().
#'x can also be an object of class data.frame containing sample genotypes. See read.gdata, $gtypes.
#' @param n number of individuals to simulate in the sample population.
#' @param pop name to label population
#' 
#' @details For each locus in x, sim.pop2 generates genotypes of n individuaks based on the population allele frequencies provided. Allele frequencies
#' are utilized as the probability of assigning an allele at a given locus in each individual.
#' @keywords simulate, genotypes, population
#' @author Tyler Jackson
#' @export
#' @examples 
#' sim.pop2(af, n=200)

sim.pop2 <- function(x, n, pop){
  if(class(x)=="data.frame"){
    A <- allele.freq(x)} else{if(class(x)=="list"){A <- x}else{stop("Cannot recognize class of 'x'")}}

P <- list()
for(e in 1:1000){
  Q <- data.frame(Ind=1:n, Pop=pop)
  for(i in 1:length(A)){
    allele.uno <- sample(A[[i]][,1], n, prob=A[[i]][,2], replace=T) #draw alleles to be genotypes 
    allele.dos <- sample(A[[i]][,1], n, prob=A[[i]][,2], replace=T)
    gtype <- as.data.frame(cbind(allele.uno,allele.dos))
    names(gtype) <- c(paste0(names(A)[i],"_", 1:2))
    Q <- cbind(Q, gtype)
  }
  P[[e]] <- Q
}

R <- do.call("rbind", P)
Q2 <- sample(1:nrow(R), n, rep=F)
QQ <- R[Q2,]
QQ$Ind <- c(1:n)
row.names(QQ) <- c(1:nrow(QQ))
QQ
}