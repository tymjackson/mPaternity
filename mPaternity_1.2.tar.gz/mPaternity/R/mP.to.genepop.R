#' Change Genetic Data Format from mPaternity to Genepop
#'
#' This function converts multilocus genotypes of individuals used in mPaternity to being formatted as an input file for the software program Genepop (Raymond and Rousset 1995; Rousset 2008)
#' @param x object of class data.frame. See output of read.gdata(), $g.types
#' @param file character string indicating the desired name of the file. "_genepop.gen" will automatically be added on.
#' @param export logical operater to determine if data should be stored in the environment as an object of class data.frame (FALSE) or exported as a text file (TRUE).
#' @details A text file in the Genepop input file format will be saved in the working directory.
#' @keywords genotypes, Genepop
#' @author Tyler Jackson
#' @references Raymond M. & Rousset F, 1995. GENEPOP (version 1.2): population genetics software for exact tests and ecumenicism. J. Heredity, 86:248-249.
#' @references Rousset, F., 2008. Genepop'007: a complete reimplementation of the Genepop software for Windows and Linux. Mol. Ecol. Resources 8: 103-106.
#' @export
#' @examples
#' mP.to.genepop(mydata$g.types, file="mydata")

mP.to.genepop <- function(x, export=T, file){
  loci <- names(allele.freq(x))
  af <- allele.freq(x)
  af <- lapply(af, function(q){cbind(q, "number"=c(1:nrow(q)))})
  af <- lapply(af, function(q){q[,3]<-sprintf("%02d", q[,3]); q})
  na <- data.frame(Allele=0, Frequency=0, number="00")
  af <- lapply(af, function(q){rbind(q, na)})
  
  x[is.na(x)] <- 0
  
  C <- matrix(nrow=nrow(x), ncol=length(af))
  for(i in 1:length(af)){
    for(j in 1:nrow(x)){
      C[j,i] <- paste0(af[[i]][,3][af[[i]][,1]==x[j,(i*2)+1]],af[[i]][,3][af[[i]][,1]==x[j,(i*2)+2]])
    }
  }
  C <- as.data.frame(C)
  C <- cbind("pop"=x$Pop,C)
  C$pop <- paste0(C$pop, ",")
  C$pop <- factor(C$pop,levels=unique(C$pop))
  C <- split(C, factor(C$pop),)
  G <- matrix(nrow=1, ncol=ncol(C[[1]])-1, rep("",ncol(C[[1]])-1))
  G <- as.data.frame(G)
  G <- cbind("pop"="Pop", G)
  C <- lapply(C, function(q){rbind(G, q)})
  C <- do.call("rbind", C)
  row.names(C) <- c(1:nrow(C))
  names(C) <- c("pop", rep("", ncol(C)-1))
  
  H <- matrix(nrow=length(af), ncol=ncol(C), rep("",length(af)*ncol(C)))
  H[,1] <- names(af); H <- as.data.frame(H)
  names(H) <- c("pop", rep("",ncol(H)-1))
  
  C <- rbind(H, C)
  names(C)[1] <- "Genepop Input"

  if(export==F){C} else{
  write.table(C, paste0(file,"_genepop.gen"), row.names=FALSE, sep="\t", quote = FALSE)
  }
}
