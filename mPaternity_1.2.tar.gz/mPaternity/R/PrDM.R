#' Power analysis for detecting multiple paternites
#'
#' This function runs the software PrDM (Neff and Pitcher 2002).
#' @param pop.types object of class data.frame containing genotypes of population sample. See output of read.gdata, $g.types. Cannot handle more than 25 loci and 30 alleles per locus.
#' 
#' @param n.offspring number of offspring sampled from a brood (required), default = 10, maximum = 100.
#' 
#' @param n.sires true number of sires that contributed to the brood (required), default = 2, maximum = 10.
#' 
#' @param fert.success probability of fertilization succes of each putative sire. Must be equivalent to 1. (required) Example: c(0.5,0.5)
#' 
#' @param mom.gtype object of class data.frame (with only 1 row) containing the genotype of the known parent (mother). See output of read.gdata, $g.types
#' @details PrDM calculates the probability of detecting multiple mating in a brood, given several user defined parameters. This
#' model is used to determine the number of loci and offspring that are required to detect multiply mated broods with high probability (Neff and Pitcher 2002).
#' @keywords populations, multiple paternity, power analysis
#' @author Tyler Jackson, PrDM: Neff and Pitcher (2002)
#' @export
#' @references Neff BD, Pitcher TE (2002) Assessing the statistical power of genetic analyses to detect multiple mating in fishes. Journal of Fish Biology 61: 739-750.
#' @examples
#' PrDM(popdat, n.offspring=15, n.sires=4, fert.success=c(0.25,0.25,0.25,0.25), mom)


PrDM <- function(pop.gtypes, n.offspring, n.sires, fert.success, mom.gtype){
if(missing(n.offspring)){stop("Must provide the number of offspring to be sampled.")}
if(missing(n.sires)){stop("Must provide the number of sires.")}  
if(missing(fert.success)){stop("Must provide a vector containing the probability of success for each putative sire.")}  
#if(sum(fert.success!=1)){stop("Sum of fert.success must be equivalent to 1.")}
tmp.path <- paste0(getwd(),"/tmpfolder")
dir.create(tmp.path)
setwd(tmp.path)
download.file("http://publish.uwo.ca/~bneff/software/prdm/prdm.exe", destfile="prdm.exe", mode="wb") #download prdm.exe from Bryan Neff' website
if (file.exists("prdm.exe")==F){stop("URL path changed. File not available, see github")}
####create the mmdata.txt file####

afreqs <- allele.freq(pop.gtypes)
nloci <- length(afreqs)


if(missing(mom.gtype)){mtype <- c(rep(99, nloci))} else{
for( i in 1:length(afreqs)){
  afreqs[[i]]$num <- c(0:(nrow(afreqs[[i]])-1))
}
loc <- names(mom.gtype)
loc <- loc[grepl("_1", loc)]
loc <- gsub("_1","",loc)
output <- list(NULL)
d <- NULL
for(i in 1:length(loc)){
  d <- mom.gtype[,grep(pattern=paste0(loc[i], "_"),x=names(mom.gtype))] 
  h <- c(d[,1],d[,2])
  l <-NULL
  for(j in 1:length(h)){
    l[j] <- afreqs[[i]]$num[afreqs[[i]]$Allele==h[j]]
  }
  output[[i]] <- data.frame(Allele=h, num=l)
}
names(output) <- loc
out <- do.call(rbind, output)
mtype <- out$num
}
tmpall <- lapply(afreqs, nrow)
nall <- NULL
for (i in 1:length(tmpall)){
  nall[i] <- tmpall[[i]]
}
maxi <- max(c(nall, nloci, length(mtype)))
tmpdf <- data.frame()

for (i in 1:nloci){
  tmpv <- c(nall[i],afreqs[[i]]$Frequency, rep(NA, maxi-nall[i]))
  tmpdf <- rbind(tmpdf,tmpv)
  names(tmpdf) <- c(1:ncol(tmpdf))
}
tmpdf <- rbind(c(nloci,rep(NA, maxi)), tmpdf)
tmpdf <- rbind(tmpdf, c(n.sires, fert.success, rep(NA, maxi-n.sires+1)))
mtype2 <- c(mtype,rep(NA, (maxi+1)-length(mtype)))
tmpdf <- rbind(tmpdf, mtype2)

write.table(tmpdf, "mmdata.txt", row.names = F, col.names = F, sep="\t", na="")
####################################

system("prdm.exe",show.output.on.console = T, input=c(as.character(n.offspring), "0"), minimized  =T)

setwd('..')
unlink(tmp.path, recursive = T)
}












