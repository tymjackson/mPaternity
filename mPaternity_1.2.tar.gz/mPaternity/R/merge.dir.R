#' Combine two or more directories.
#'
#' This function merges all files of two or more directories (i.e. creates a copy). Files do not need to be of the same name or file type.
#' @param x path of parent directories (containing sub directories which are to be merged).
#' @details A new directory named 'Merged Directory' will be created containing all the contents of the merged directories. Working directory must be x.
#' @keywords merge, folder, file, directory
#' @author Tyler Jackson
#' @export
#' @examples
#' merge.dir(dir.path)

merge.dir <- function(x){
setwd(x)
newdir <- (paste0(x,"/Merged Directory"))
C <- list.files() #name subdirectories
my_dirs <- c(paste0(getwd(),"/",C))
files <- sapply(my_dirs, list.files, full.names = TRUE)
new_dir <- "Merged Directory"
dir.create(new_dir, recursive = TRUE)
# Copy the files
for(file in files) {
  # See ?file.copy for more options
  file.copy(file, new_dir)
}
}
